import * as THREE from '../libs/three.module.js'

class MyFigure extends THREE.Object3D {
    constructor(gui,titleGui) {
        super();
        
        // Se crea la parte de la interfaz que corresponde a la caja
        // Se crea primero porque otros métodos usan las variables que se definen para la interfaz
        this.createGUI(gui,titleGui)

        // Materiales de color
        this.material = new THREE.MeshNormalMaterial()
        this.materialazul = new THREE.MeshPhongMaterial({color: 0x0000FF })
        this.materialrojo = new THREE.MeshPhongMaterial({color: 0xFF0000})
        this.materialverde = new THREE.MeshPhongMaterial({color: 0x00FF00 })

        /*
        var points = [];
        this.createBaseReloj(points)

        var latheObject = new THREE.Mesh (new THREE.LatheGeometry (points, 30), this.materialazul);

        var cunia = new THREE.Shape();
        cunia.moveTo(0,7.5)
        cunia.quadraticCurveTo(2.5,7.5,2.5,5.5)
        cunia.lineTo(2.5,)
        cunia.lineTo(2.5,0)
        var cuniaGeom = new THREE.ExtrudeGeometry (cunia)
        this.cuniamesh = new THREE.Mesh(cuniaGeom, this.materialazul)
        //this.add(this.cuniamesh)
        */

        this.boxEscenarioGeom = new THREE.BoxGeometry(40, 1, 40)
        this.boxEscenarioGeom.translate(0,-1,0)
        this.boxEscenario = new THREE.Mesh(this.boxEscenarioGeom, this.materialazul)
        this.add(this.boxEscenario)

        this.rotacion = (Math.PI*2/12); //rotacion para cada hora

        this.rectanguloGeomUno = new THREE.BoxGeometry(2.0,0.5,0.5)
        this.rectanguloGeomUno.translate(7,0,0)
        
        //Para las marcas
        for(let i = 0; i < 12; i++){
            var rectanguloMarcaUno = new THREE.Mesh(this.rectanguloGeomUno,this.material)
            rectanguloMarcaUno.rotation.y = (i*this.rotacion)
            this.add(rectanguloMarcaUno)
        }

        this.rectanguloGeomDos = new THREE.BoxGeometry(2.0,0.5,0.5)
        this.rectanguloGeomDos.translate(15,0,0)

        for(let i = 0; i < 12; i++){
            var rectanguloMarcaDos = new THREE.Mesh(this.rectanguloGeomDos,this.material)
            rectanguloMarcaDos.rotation.y = (i*this.rotacion)
            this.add(rectanguloMarcaDos)
        }

        this.esferaExtGeom = new THREE.SphereGeometry(1,20,20);
        this.esferaExtGeom.translate(12, 0, 0);
        this.esferaExt = new THREE.Mesh(this.esferaExtGeom, this.material);
        this.add(this.esferaExt);

        this.esferaIntGeom = new THREE.SphereGeometry(1,20,20);
        this.esferaIntGeom.translate(4.5, 0, 0);
        this.esferaInt = new THREE.Mesh(this.esferaIntGeom, this.material);
        this.add(this.esferaInt);
        
        this.reloj = new THREE.Clock();

    }
  
    createBaseReloj(points){

        var cunia = new THREE.Shape();
        cunia.moveTo(0,7.5)
        cunia.quadraticCurveTo(2.5,7.5,2.5,5.5)
        cunia.lineTo(0,0)
        cunia.lineTo(2.5,0)
        var cuniaGeom = new THREE.ExtrudeGeometry (cunia)
    }

    createGUI (gui,titleGui) {
        // Controles para el tamaño, la orientación y la posición de la caja
        this.guiControls = {
            velocidad : 1.0,
        }
    
        // Se crea una sección para los controles de la caja
        var folder = gui.addFolder (titleGui)
        
    }
  
    update () {
		// Con independencia de cómo se escriban las 3 siguientes líneas, el orden en el que se aplican las transformaciones es:
        // Primero, el escalado
        // Segundo, la rotación en Z
        // Después, la rotación en Y
        // Luego, la rotación en X
        // Y por último la traslación
    
        this.esferaExt.rotation.y -= this.rotacion * this.reloj.getDelta()

        this.esferaInt.rotation.y -= this.rotacion * this.reloj.getDelta()

    }
}

export { MyFigure };
